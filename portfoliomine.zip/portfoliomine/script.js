// --- Reveal on Scroll Logic ---
const observerOptions = {
    threshold: 0.15 // Triggers when 15% of the section is visible
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('reveal-visible');
        }
    });
}, observerOptions);

// Target all sections to animate
document.querySelectorAll('section').forEach(section => {
    section.classList.add('reveal-hidden');
    observer.observe(section);
});

// --- Back to Top Button Logic ---
const topBtn = document.createElement('button');
topBtn.innerHTML = '↑';
topBtn.setAttribute('id', 'backToTop');
document.body.appendChild(topBtn);

window.onscroll = () => {
    if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
        topBtn.style.display = "block";
    } else {
        topBtn.style.display = "none";
    }
};

topBtn.onclick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
};